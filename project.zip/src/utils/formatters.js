export const formatPrice = (price, operation = 'venta') => {
  const formatter = new Intl.NumberFormat('es-MX', {
    style: 'currency',
    currency: 'MXN',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  });
  
  const formattedPrice = formatter.format(price);
  return operation === 'renta' ? `${formattedPrice}/mes` : formattedPrice;
};

export const formatSurface = (surface) => {
  return `${surface} m²`;
};

export const formatDate = (dateString) => {
  const date = new Date(dateString);
  return date.toLocaleDateString('es-MX', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
};

export const generateWhatsAppLink = (phone, propertyTitle, clientName = '', clientPhone = '') => {
  const message = `Hola! Me interesa la propiedad: ${propertyTitle}${clientName ? `\n\nMis datos:\nNombre: ${clientName}` : ''}${clientPhone ? `\nTeléfono: ${clientPhone}` : ''}\n\n¿Podrían darme más información?`;
  
  return `https://wa.me/52${phone}?text=${encodeURIComponent(message)}`;
};

export const getPropertyTypeIcon = (type) => {
  const icons = {
    casa: '🏠',
    departamento: '🏢',
    local: '🏪',
    oficina: '🏢',
    terreno: '🌍'
  };
  return icons[type] || '🏠';
};